﻿
namespace Lab1_Server.Settings
{
    public class MainSettings
    {
        public int Field { get; set; }
    }
}
